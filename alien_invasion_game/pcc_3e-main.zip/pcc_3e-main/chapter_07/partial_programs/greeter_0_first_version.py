name = input("Please enter your name: ")
print(f"\nHello, {name}!")