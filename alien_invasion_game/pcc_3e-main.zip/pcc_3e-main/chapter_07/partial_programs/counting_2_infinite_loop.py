# This loop runs forever!
x = 1
while x <= 5:
    print(x)