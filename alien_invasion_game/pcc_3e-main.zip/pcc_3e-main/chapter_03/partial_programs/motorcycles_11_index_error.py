motorcycles = ['honda', 'yamaha', 'suzuki']
print(motorcycles[3])