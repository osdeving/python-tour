bicycles = ['trek', 'cannondale', 'redline', 'specialized']
print(bicycles)