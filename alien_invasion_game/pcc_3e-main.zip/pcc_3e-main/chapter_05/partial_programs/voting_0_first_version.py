age = 19
if age >= 18:
    print("You are old enough to vote!")