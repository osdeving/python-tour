from pizza import make_pizza as mp


mp(16, 'pepperoni')
mp(12, 'mushrooms', 'green peppers', 'extra cheese')