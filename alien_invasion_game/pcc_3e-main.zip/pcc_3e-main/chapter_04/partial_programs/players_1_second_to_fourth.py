players = ['charles', 'martina', 'michael', 'florence', 'eli']
print(players[1:4])