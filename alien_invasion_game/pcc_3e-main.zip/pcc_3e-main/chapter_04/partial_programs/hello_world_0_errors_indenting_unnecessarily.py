message = "Hello Python world!"
    print(message)